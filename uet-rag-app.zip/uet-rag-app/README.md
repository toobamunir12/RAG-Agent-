# UET Mardan Prospectus Assistant

A full RAG chat app: your existing `ingestion_pipeline.py` + `rag_agent.py` (unchanged, using acruxcore)
behind a FastAPI wrapper, with a React chat UI on top.

```
uet-rag-app/
  backend/
    ingestion_pipeline.py   # unchanged from your upload
    rag_agent.py            # unchanged from your upload (still uses acruxcore)
    server.py                # NEW - FastAPI wrapper exposing POST /api/chat
    requirements.txt
    .env.example
  frontend/
    src/App.jsx              # NEW - chat UI
    src/App.css
    src/index.css
    ...                       # Vite + React scaffold
```

## 1. Index your prospectus (one-time, or whenever the PDF changes)

```bash
cd backend
pip install -r requirements.txt
python ingestion_pipeline.py --source /path/to/uet_mardan_prospectus.pdf
```

This builds the `chroma_store/` folder that `server.py` and `rag_agent.py` read from.

## 2. Run the backend API

```bash
cd backend
cp .env.example .env   # fill in ALLOWED_ORIGINS + whatever acruxcore needs
uvicorn server:app --reload --port 8000
```

Check it's alive: `curl http://localhost:8000/api/health` → `{"status":"ok"}`

`server.py` doesn't touch your agent logic — it just calls `ask()` from `rag_agent.py` and
turns it into `POST /api/chat { "question": "..." } -> { "answer": "..." }`, with a friendly
error if the Chroma collection hasn't been built yet.

## 3. Run the frontend

```bash
cd frontend
npm install
cp .env.example .env   # VITE_API_BASE, defaults to http://localhost:8000
npm run dev
```

Open the printed localhost URL (default `http://localhost:5173`). Type a question or tap
one of the suggested prompts — the UI shows a "consulting the prospectus" loading state,
then the answer in a card, or a clear error card if indexing hasn't happened yet or the
backend is unreachable.

## Notes / things you may want to change

- **CORS**: `server.py` reads allowed origins from `ALLOWED_ORIGINS` (comma-separated).
  Update it when you deploy the frontend somewhere other than `localhost:5173`.
- **Streaming**: `ask()` currently returns the full answer at once, so the UI shows a
  loading state rather than token-by-token streaming. If `hub.run_tool_loop` in acruxcore
  supports streaming, `server.py` could be adapted to a Server-Sent Events / WebSocket
  endpoint instead of a plain POST — happy to do that next if you want it.
- **Sources**: `search_docs` currently returns raw page text without page numbers to the
  agent. If you want the UI to show "see page 12" citations, that would mean returning
  metadata alongside the text from `search_docs` and threading it through to the API
  response — a small change to `rag_agent.py`, not `server.py`.
