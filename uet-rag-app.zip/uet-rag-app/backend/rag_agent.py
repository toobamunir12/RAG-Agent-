import asyncio

import chromadb
import acruxcore as acrux
from dotenv import load_dotenv

from ingestion_pipeline import get_embedding  # only reuse this -- same embedding model as indexing

load_dotenv()

CHROMA_PATH = "chroma_store"
COLLECTION_NAME = "uet_mardan_prospectus"


@acrux.tool
async def search_docs(query: str) -> str:
    """Searches the UET Mardan undergraduate prospectus for passages relevant to the query."""
    client = chromadb.PersistentClient(path=CHROMA_PATH)
    collection = client.get_collection(COLLECTION_NAME)
    query_embedding = get_embedding(query)
    results = collection.query(
        query_embeddings=[query_embedding],
        n_results=3,
    )
    documents = results["documents"][0]
    context = "\n\n".join(documents)
    return context


async def ask(question: str) -> str:
    hub = acrux.AcruxCore()
    rendered = await hub.render_prompt(
        "uet-rag-agent",
        "production",
        {"question": question},
    )
    result = await hub.run_tool_loop(
        model="rag-model",
        messages=rendered.messages,
        tools=[search_docs],
    )
    return result.content


if __name__ == "__main__":
    question = input("Ask a question about UET Mardan: ")
    answer = asyncio.run(ask(question))
    print("\nAnswer:")
    print(answer)
